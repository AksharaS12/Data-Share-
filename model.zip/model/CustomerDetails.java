/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.store.store_akshara_2022.model;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 *
 * @author abhi
 */
@Entity
@Table(name = "customer_details")
@NamedQueries({
    @NamedQuery(name = "CustomerDetails.findAll", query = "SELECT c FROM CustomerDetails c")})
public class CustomerDetails implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "customer_id")
    private Integer customerId;
    @Size(max = 45)
    @Column(name = "first_name")
    private String firstName;
    @Size(max = 45)
    @Column(name = "second_name")
    private String secondName;
    @Size(max = 45)
    @Column(name = "telephone_number")
    private String telephoneNumber;
    @Size(max = 45)
    @Column(name = "password")
    private String password;
    @Column(name = "is_deleted")
    private Short isDeleted;
    @Size(max = 45)
    @Column(name = "email_id")
    private String emailId;
    @JoinColumn(name = "role_id", referencedColumnName = "role_id")
    @ManyToOne
    private MasterRole masterRole;
    @OneToMany(mappedBy = "customerDetails")
    private Collection<AddressDetails> addressDetailsCollection;
    @OneToMany(mappedBy = "customerDetails")
    private Collection<CartDetails> cartDetailsCollection;
    @OneToMany(mappedBy = "customerDetails")
    private Collection<ProductDetails> productDetailsCollection;

    public CustomerDetails() {
    }

    public CustomerDetails(Integer customerId) {
        this.customerId = customerId;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Short getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Short isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public MasterRole getMasterRole() {
        return masterRole;
    }

    public void setMasterRole(MasterRole masterRole) {
        this.masterRole = masterRole;
    }

    public Collection<AddressDetails> getAddressDetailsCollection() {
        return addressDetailsCollection;
    }

    public void setAddressDetailsCollection(Collection<AddressDetails> addressDetailsCollection) {
        this.addressDetailsCollection = addressDetailsCollection;
    }

    public Collection<CartDetails> getCartDetailsCollection() {
        return cartDetailsCollection;
    }

    public void setCartDetailsCollection(Collection<CartDetails> cartDetailsCollection) {
        this.cartDetailsCollection = cartDetailsCollection;
    }

    public Collection<ProductDetails> getProductDetailsCollection() {
        return productDetailsCollection;
    }

    public void setProductDetailsCollection(Collection<ProductDetails> productDetailsCollection) {
        this.productDetailsCollection = productDetailsCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (customerId != null ? customerId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CustomerDetails)) {
            return false;
        }
        CustomerDetails other = (CustomerDetails) object;
        if ((this.customerId == null && other.customerId != null) || (this.customerId != null && !this.customerId.equals(other.customerId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.store.store_akshara_2022.model.CustomerDetails[ customerId=" + customerId + " ]";
    }
    
}
