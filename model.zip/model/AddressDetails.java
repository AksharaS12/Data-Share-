/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.store.store_akshara_2022.model;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author abhi
 */
@Entity
@Table(name = "address_details")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "AddressDetails.findAll", query = "SELECT a FROM AddressDetails a"),
    @NamedQuery(name = "AddressDetails.findByAddressId", query = "SELECT a FROM AddressDetails a WHERE a.addressId = :addressId"),
    @NamedQuery(name = "AddressDetails.findByHouse", query = "SELECT a FROM AddressDetails a WHERE a.house = :house"),
    @NamedQuery(name = "AddressDetails.findByAddressLine1", query = "SELECT a FROM AddressDetails a WHERE a.addressLine1 = :addressLine1"),
    @NamedQuery(name = "AddressDetails.findByAddressLine2", query = "SELECT a FROM AddressDetails a WHERE a.addressLine2 = :addressLine2"),
    @NamedQuery(name = "AddressDetails.findByPostCode", query = "SELECT a FROM AddressDetails a WHERE a.postCode = :postCode"),
    @NamedQuery(name = "AddressDetails.findByIsDeleted", query = "SELECT a FROM AddressDetails a WHERE a.isDeleted = :isDeleted")})
public class AddressDetails implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "address_id")
    private Integer addressId;
    @Size(max = 45)
    @Column(name = "house")
    private String house;
    @Size(max = 45)
    @Column(name = "address_line1")
    private String addressLine1;
    @Size(max = 45)
    @Column(name = "address_line2")
    private String addressLine2;
    @Size(max = 45)
    @Column(name = "post_code")
    private String postCode;
    @Column(name = "is_deleted")
    private Short isDeleted;
    @JoinColumn(name = "customer_id", referencedColumnName = "customer_id")
    @ManyToOne
    private CustomerDetails customerId;
    @JoinColumn(name = "country", referencedColumnName = "country_id")
    @ManyToOne(optional = false)
    private MasterCountry country;
    @OneToMany(mappedBy = "addressId")
    private Collection<CartDetails> cartDetailsCollection;

    public AddressDetails() {
    }

    public AddressDetails(Integer addressId) {
        this.addressId = addressId;
    }

    public Integer getAddressId() {
        return addressId;
    }

    public void setAddressId(Integer addressId) {
        this.addressId = addressId;
    }

    public String getHouse() {
        return house;
    }

    public void setHouse(String house) {
        this.house = house;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public Short getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Short isDeleted) {
        this.isDeleted = isDeleted;
    }

    public CustomerDetails getCustomerId() {
        return customerId;
    }

    public void setCustomerId(CustomerDetails customerId) {
        this.customerId = customerId;
    }

    public MasterCountry getCountry() {
        return country;
    }

    public void setCountry(MasterCountry country) {
        this.country = country;
    }

    @XmlTransient
    public Collection<CartDetails> getCartDetailsCollection() {
        return cartDetailsCollection;
    }

    public void setCartDetailsCollection(Collection<CartDetails> cartDetailsCollection) {
        this.cartDetailsCollection = cartDetailsCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (addressId != null ? addressId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AddressDetails)) {
            return false;
        }
        AddressDetails other = (AddressDetails) object;
        if ((this.addressId == null && other.addressId != null) || (this.addressId != null && !this.addressId.equals(other.addressId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.store.store_akshara_2022.model.AddressDetails[ addressId=" + addressId + " ]";
    }
    
}
