/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.store.store_akshara_2022.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author abhi
 */
@Entity
@Table(name = "cart_details")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CartDetails.findAll", query = "SELECT c FROM CartDetails c"),
    @NamedQuery(name = "CartDetails.findByCartId", query = "SELECT c FROM CartDetails c WHERE c.cartId = :cartId"),
    @NamedQuery(name = "CartDetails.findByCartDate", query = "SELECT c FROM CartDetails c WHERE c.cartDate = :cartDate"),
    @NamedQuery(name = "CartDetails.findByCartQuantity", query = "SELECT c FROM CartDetails c WHERE c.cartQuantity = :cartQuantity"),
    @NamedQuery(name = "CartDetails.findByIsDeleted", query = "SELECT c FROM CartDetails c WHERE c.isDeleted = :isDeleted")})
public class CartDetails implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "cart_id")
    private Integer cartId;
    @Column(name = "cart_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date cartDate;
    @Column(name = "cart_quantity")
    private Integer cartQuantity;
    @Column(name = "is_deleted")
    private Short isDeleted;
    @JoinColumn(name = "address_id", referencedColumnName = "address_id")
    @ManyToOne
    private AddressDetails addressId;
    @JoinColumn(name = "cart_by", referencedColumnName = "customer_id")
    @ManyToOne
    private CustomerDetails cartBy;
    @JoinColumn(name = "cart_type", referencedColumnName = "cart_type_id")
    @ManyToOne
    private MasterCartType cartType;
    @JoinColumn(name = "product_id", referencedColumnName = "product_id")
    @ManyToOne
    private ProductDetails productId;

    public CartDetails() {
    }

    public CartDetails(Integer cartId) {
        this.cartId = cartId;
    }

    public Integer getCartId() {
        return cartId;
    }

    public void setCartId(Integer cartId) {
        this.cartId = cartId;
    }

    public Date getCartDate() {
        return cartDate;
    }

    public void setCartDate(Date cartDate) {
        this.cartDate = cartDate;
    }

    public Integer getCartQuantity() {
        return cartQuantity;
    }

    public void setCartQuantity(Integer cartQuantity) {
        this.cartQuantity = cartQuantity;
    }

    public Short getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Short isDeleted) {
        this.isDeleted = isDeleted;
    }

    public AddressDetails getAddressId() {
        return addressId;
    }

    public void setAddressId(AddressDetails addressId) {
        this.addressId = addressId;
    }

    public CustomerDetails getCartBy() {
        return cartBy;
    }

    public void setCartBy(CustomerDetails cartBy) {
        this.cartBy = cartBy;
    }

    public MasterCartType getCartType() {
        return cartType;
    }

    public void setCartType(MasterCartType cartType) {
        this.cartType = cartType;
    }

    public ProductDetails getProductId() {
        return productId;
    }

    public void setProductId(ProductDetails productId) {
        this.productId = productId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cartId != null ? cartId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CartDetails)) {
            return false;
        }
        CartDetails other = (CartDetails) object;
        if ((this.cartId == null && other.cartId != null) || (this.cartId != null && !this.cartId.equals(other.cartId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.store.store_akshara_2022.model.CartDetails[ cartId=" + cartId + " ]";
    }
    
}
